# DeepLearning.AI

These are the notebooks that accompany the [DeepLearning.AI](https://www.deeplearning.ai)'s short course, [Large Multimodal Model (LMM) Prompting with Gemini](https://learn.deeplearning.ai/courses/large-multimodal-model-prompting-with-gemini/lesson/1/introduction), built in partnership with Google Cloud.

The short course is available to take on [DeepLearning.AI's Learning Platform](https://learn.deeplearning.ai).
